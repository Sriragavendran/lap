package lap02.exercise01;

import java.util.Arrays;
import java.util.Scanner;

public class SecondLargest {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("Enter the size of Array");
	int size=scanner.nextInt();
	int arr[]=new int[size];
	System.out.println("Enter the array Element");
	for(int i=0;i<size;i++) {
		arr[i]=scanner.nextInt();
	}
	System.out.println("The Second Largest element in the array is "+getSecondLargest(arr));
}

private static int getSecondLargest(int[] arr) {
	Arrays.sort(arr);
	return arr[arr.length-2];
}
}
