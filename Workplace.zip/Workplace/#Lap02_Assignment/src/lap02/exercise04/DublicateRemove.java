package lap02.exercise04;

import java.util.Arrays;
import java.util.Scanner;

public class DublicateRemove {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the size of Array");
		int num = scanner.nextInt();
		int[] arr = new int[num];
		for (int i = 0; i < num; i++) {
			arr[i] = scanner.nextInt();
		}
		int result[] = modifyArray(arr);
		for (int i = result.length-1; i >= 0; i--) {
			if(arr[i]!='@')
			System.out.println(result[i]);
		}

	}

	private static int[] modifyArray(int[] arr) {
		Arrays.sort(arr);
		for(int i=0;i<arr.length-1;i++) {
			if(arr[i]==arr[i+1]) {
				arr[i]='@';
			}
		}
		return arr;
	}

}
