package lap02.exercise02;

import java.util.Arrays;
import java.util.Scanner;

public class StringSort {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the size of Array");
		int num=scanner.nextInt();
		String []strings=new String[num];
		for(int i=0;i<num;i++) {
			strings[i]=scanner.next();
		}
		String result[]=sortStrings(strings);
		
		for(int i=0;i<num;i++) {
			if(num%2==0&&i<num/2)
			System.out.println(result[i].toUpperCase());
			else if(num%2!=0&&i<=num/2)
				System.out.println(result[i].toUpperCase());
			else
				System.out.println(result[i].toLowerCase());
		}

	}

	private static String[] sortStrings(String[] strings) {
		Arrays.sort(strings);
		return strings;
	}

}
