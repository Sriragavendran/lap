package lap06.exercise02;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise2Collection {



	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int i=0;
		char ar[]=new char[10];
		for(i=0;i<10;i++) {
			ar[i]=scanner.next().charAt(0);
		}
		Map<Character, Integer> map=countChars(ar);
		for(Character m:map.keySet()) {
			System.out.println(m+" -- "+map.get(m));
		}

	}

	private static Map<Character, Integer> countChars(char[] ar) {
		Map<Character, Integer> map=new HashMap<>();
		for(int i=0;i<ar.length;i++) {
			if(map.containsKey(ar[i])) {
				map.put(ar[i],map.get(ar[i])+1);
			}
			else {
				map.put(ar[i], 1);
			}
		}
		return map;
	}

}
