package lap06.exercise03;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Squars {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int i = 0;
		int ar[] = new int[10];
		for (i = 0; i < 10; i++) {
			ar[i] = scanner.nextInt();
		}
		Map<Integer, Integer> map = getSquars(ar);
		for (Integer m : map.keySet()) {
			System.out.println(m + " -- " + map.get(m));
		}

	}

	private static Map<Integer, Integer>  getSquars(int[] ar) {
		Map<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < ar.length; i++) {
			map.put(ar[i], ar[i]*ar[i]);
		}
		return map;
	}

}
