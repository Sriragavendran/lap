package lap06.exercise04;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;


public class SecondSmallest {
   public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	int[] arr =new int [10];
	int i=0;
	while(i<10) {
		
		arr[i]=scanner.nextInt();
		i++;
	}
	
	System.out.println("The Second smallest is "+getSecondSmallest(arr));
}

private static int getSecondSmallest(int[] arr) {
    List<Integer> list=Arrays.stream(arr).boxed().collect(Collectors.toList());
	Collections.sort(list);
	//System.out.println(list.get(1));
	
	return list.get(1);
	
}
}
