package lap06.exercise07;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class ReverseSort {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of Array");
		int num = scanner.nextInt();
		int[] arr = new int[num];
		for (int i = 0; i < num; i++) {
			arr[i] = scanner.nextInt();
		}
		int result[] = getSorted(arr);
		for (int i = 0; i <num; i++) {
			System.out.println(result[i]);
		}
	}

	private static int[] getSorted(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			String string=String.valueOf(arr[i]);
			char []c=new char[string.length()];
			for(int j=0;j<string.length();j++ ) {
				c[j]=string.charAt(string.length()-1-j);
			}
		
			arr[i]=Integer.parseInt(String.valueOf(c));
		}
		Arrays.sort(arr);
		return arr;
	}
}
