package lap06.exercise01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;


public class MapSort {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Elements");
	    HashMap<Integer,Integer> mapSort=new HashMap();
	    int i=0;
	    while(i<10) {
	    	mapSort.put(i, scanner.nextInt());
	    	i++;
	    }
	    ArrayList<Integer> list=getValues(mapSort);
	    System.out.println("Sorted elements");
	    for(Integer i1:list) {
	    	System.out.println(i1);
	    }

	}

	private static ArrayList<Integer> getValues(HashMap<Integer,Integer> mapSort) {
	   ArrayList<Integer> list=new ArrayList<>();
	   for(Integer i:mapSort.keySet()) {
		   list.add(mapSort.get(i));
		   
	   }
	   Collections.sort(list);
		return list;
	}

}
