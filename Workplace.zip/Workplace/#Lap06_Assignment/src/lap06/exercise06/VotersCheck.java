package lap06.exercise06;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;



public class VotersCheck {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		Map <Integer,String> map=new HashMap<Integer,String>();
		for(int i=0;i<10;i++) {
			map.put(scan.nextInt(),scan.next());
		}
		ArrayList<String> nameArrayList=getVoters(map);
		for(String i:nameArrayList) {
			System.out.println(i);
		}

	}

	private static ArrayList<String> getVoters(Map<Integer, String> map) {
		ArrayList<String> list=new ArrayList<>();
		for(Integer integer:map.keySet()) {
			if(integer>=18)
			list.add(map.get(integer));
		}
		return list;
	}
	
}
