package test3;

public class OddOrEven {
	public static void main(String[] args) {
		for(int i=0;i<args.length;i++) {
			if(Integer.parseInt(args[i])%2==0) {
				System.out.println(Integer.parseInt(args[i])+" is Even Number");
			}
			else {
				System.out.println(Integer.parseInt(args[i])+" is Odd Number");
			}
		}
	}

}
