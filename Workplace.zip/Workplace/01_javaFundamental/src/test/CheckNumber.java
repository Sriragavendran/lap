package test;

public class CheckNumber {

	public static void main(String[] args) {
		int num=10;
		if(num>0) {
			System.out.println("Number "+num+"is positive");
		}
		else {
			System.out.println("Number "+num+"is negative");
		}
	}

}
