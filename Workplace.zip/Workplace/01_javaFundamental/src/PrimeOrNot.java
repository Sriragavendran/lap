
public class PrimeOrNot {
    public static void prime(int number) {
    	for(int i=2;i<=Math.sqrt(number);i++) {
			if(number%i==0) {
				//System.out.println(number+" is not a Prime Number");
				return;
			}
		}
		System.out.print(number+" ");
    }
	public static void main(String[] args) {
		//int number=Integer.parseInt(args[0]);
		for(int i=1;i<1000;i++) {
			prime(i);
		}

	}

}
