package test2;

public class CheckNumber2 {

	public static void main(String[] args) {
		int number=Integer.parseInt(args[0]);
		if(number%2==0) {
			System.out.println("Number "+number+"is even");
		}
		else {
			System.out.println("Number "+number+"is odd");
		}
		
	}

	

}
