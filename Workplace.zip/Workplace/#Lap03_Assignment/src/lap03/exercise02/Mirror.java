package lap03.exercise02;

import java.util.Scanner;

public class Mirror {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String");
		String string = scanner.next();
		System.out.println(getImage(string));

	}

	private static String getImage(String string) {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(string);
		stringBuffer.reverse();
		String string2 = stringBuffer.toString();
		String string3 = string + "|" + string2;
		return string3;
	}

}
