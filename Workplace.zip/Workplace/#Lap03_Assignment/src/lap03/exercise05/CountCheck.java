package lap03.exercise05;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;


public class CountCheck {

	public static void main(String[] args) throws Exception {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the String");
		String string=scanner.nextLine();
		String str[]=string.split(" ");
		int characterCount=0;
		for(int i=0;i<str.length;i++) {
			characterCount+=str[i].length();
		}
		System.out.println("Character Count="+characterCount);
		System.out.println("Words Count="+str.length);

	}

}
