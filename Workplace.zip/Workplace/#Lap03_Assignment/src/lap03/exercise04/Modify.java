package lap03.exercise04;

import java.util.Scanner;

public class Modify {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number");
	int number = scanner.nextInt();
		System.out.println(modifyNumber(number));

	}

	private static int modifyNumber(int number) {
	   String string=String.valueOf(number);
	   StringBuffer stringBuffer=new StringBuffer();
	   for(int i=0;i<string.length();i++) {
		   char c=string.charAt(i);
		   char c2=string.charAt((i+1)%string.length());
		   int diff=Math.abs(Integer.parseInt(String.valueOf(c))-Integer.parseInt(String.valueOf(c2)));
		   stringBuffer.append(diff);
		   }
		return Integer.parseInt(stringBuffer.toString());
	}

}
