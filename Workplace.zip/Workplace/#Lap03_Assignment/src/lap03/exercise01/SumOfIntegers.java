package lap03.exercise01;

import java.util.Scanner;
import java.util.StringTokenizer;

public class SumOfIntegers {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int sum = 0;
		System.out.println("Enter the Integer");
		String string = scanner.nextLine();
		StringTokenizer stringTokenizer = new StringTokenizer(string, " ");
		while (stringTokenizer.hasMoreTokens()) {
			String string2 = stringTokenizer.nextToken();
			System.out.println(Integer.parseInt(string2));
			sum += Integer.parseInt(string2);
		}
		System.out.println("Sum = " + sum);
		
	}

}
