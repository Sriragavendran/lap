package lap03.exercise09;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Duration {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the Date");
		LocalDate l=LocalDate.of(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
		LocalDate date=LocalDate.now();
		//System.out.println(date);
		long p = ChronoUnit.DAYS.between(l, date);
		int m=(int) ChronoUnit.MONTHS.between(l, date);
		//System.out.println(p);
        Period period=Period.between(l, date);
        System.out.println(" days- "+p+" Month- "+m+" Year -"+period.getYears());
	

	}

}
