package lap03.exercise03;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;



public class Consonent {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the String");
		String string = scanner.next();
		System.out.println(alterString(string));


	}

	private static String alterString(String string) {
	List<Character> list=new ArrayList<>(Arrays.asList('a','e','i','o','u','A','E','I','O','U'));
	char c[]=new char[string.length()];
	for(int i=0;i<string.length();i++) {
		c[i]=string.charAt(i);
		if(!list.contains(c[i])) {
			c[i]+=1;
		}
	}
		
		return String.valueOf(c);
	}

}
