package stingFunction;

import java.util.Scanner;

public class StingMethod {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String name="Capgemini";
		System.out.println(name.charAt(0));//print the character based on the index
		System.out.println(name.codePointAt(1));//print the ASCII value of the character
		System.out.println(name.codePointBefore(1));//print the ASCII value of previous character
		System.out.println(name.compareTo("Ca"));//compare the two string and return difference
		System.out.println(name.compareToIgnoreCase("Ca"));//compare only string not case
		System.out.println(name.concat(" java"));//joint the string only print method
		System.out.println(name.contains("gm"));//check the sting or substring available in the another string
		System.out.println(name.contentEquals("Capgemi"));//check correct character sequence
		System.out.println(name.endsWith("i"));//check the last character
		System.out.println(name.indexOf("i"));//return character index
		System.out.println(name.lastIndexOf('a'));//return last index of the character
		System.out.println(name.replace('a', 'A'));//replace the character
		System.out.println(name.toLowerCase());//Converts a string to lower case letters
		System.out.println(name.toCharArray());//covert char array
		System.out.println(name.toUpperCase());//convert a string to uppercase
		System.out.println(name.substring(0,3));//make substring from given string with specified index
		System.out.println(name.trim());//remove the whitespace at both ends
		System.out.println(name.split("[e]"));//split the string based on regex pattern
		System.out.println(name.toString());//return the value of sting object
		System.out.println(name.repeat(3));//print the string at 3 time
	}

}
