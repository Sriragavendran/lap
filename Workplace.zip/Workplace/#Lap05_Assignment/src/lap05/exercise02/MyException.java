package lap05.exercise02;

public class MyException extends Exception {

	public MyException(String string) {
		System.out.println(string);
	}

}
