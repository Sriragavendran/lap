package lap05.exercise02;

import java.util.Scanner;

public class NameException{
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		try {
		System.out.println("Enter the First Name");
        String firstName=scanner.next();
        System.out.println("Enter the second name");
        String lastName=scanner.next();
        Check(firstName,lastName);
		}
		catch (Exception e) {
		    System.out.println("Please enter the valid input");
		}
	}

	 static void Check(String firstName, String lastName) throws MyException {
		if(firstName.equals(null)) {
			throw new MyException("First name is Invalid");
		}
		else if(lastName.equals(null)){
			throw new MyException("Last name is Invalid");
		}
		else {
			System.out.println("Details are Valid");
		}
		
	}
}

