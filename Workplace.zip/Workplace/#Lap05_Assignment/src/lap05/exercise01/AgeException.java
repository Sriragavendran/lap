package lap05.exercise01;

import java.util.Scanner;
class MyException extends Exception{
	MyException(String s){
		System.out.println(s);
	}
}
public class AgeException  {
  public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.print("Enter the Age");
	try {
		int age=scanner.nextInt();
		validateAge(age);
	} catch (Exception e) {
		System.out.println("Enter valid Input");
	}
	scanner.close();
}

 static void validateAge(int age) throws MyException {
	if(age<15) {
		throw  new MyException("Enter valid Age or Enter age above 15");
	}
	else {
		System.out.println("Valid age");
	}
	
}
}
