package lap05.exercise03;

import java.util.Scanner;


class MyException extends Exception{
	MyException(String s){
		System.out.println(s);
	}
}
public class EmployeeException  {
  public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.print("Enter the salary");
	try {
		double salary=scanner.nextFloat();
		validateSalary(salary);
	} catch (Exception e) {
		System.out.println("Enter valid Input");
	}
	scanner.close();
}

 static void validateSalary(Double salary) throws MyException {
	if(salary<3000) {
		throw  new MyException("Enter valid salary or Enter age above 3000");
	}
	else {
		System.out.println("Valid salary");
	}
	
}
 
}
