package com.capgemini.oop1;

public class Person {
	private String personName;
	private int personAge;

	public void showPerson() {
		System.out.println("Person Name: " + personName);
		System.out.println("Person Age: " + personAge);
	}

	public static void main(String[] args) {
		Person p1 = new Person();
		Person p2 = new Person();
		p1.personAge = 20;
		p1.personName = "Ragav";
		p1.showPerson();
		System.out.println("---------------");
		p2.personAge = 20;
		p2.personName = "Sri";
		p2.showPerson();
		System.out.println("---------------");
		p2 = p1;
		p2.showPerson();
		p1.showPerson();

	}

}
