package com.capgemini.oop4;

public class Book {
	private String bookName;
	private double bookPrice;
	private String bookAuthor;
	 
	private static double discount;
	
	public Book(String name, double price, String author) {
		this.bookName=name;
		this.bookAuthor=author;
		this.bookPrice=price;
	}

	

	public void showBook() {
		System.out.println("Book Name: " + bookName);
		System.out.println("Book Author: " + bookAuthor);
		System.out.println("Book Price: " + bookPrice);
		System.out.println("Book Discount: "+Book.discount);
		System.out.println("Book price after Discount: "+calculate());
	}



	private double calculate() {
		  return bookPrice-bookPrice*discount/100;
		//return null;
	}



	public static void setDiscount(double discount) {
		// TODO Auto-generated method stub
		Book.discount=discount;
		
	}

	
}
