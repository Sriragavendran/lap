package com.capgemini.oop5;


public class Student {
	private int studentId;
	private String name;
	private int contactNo;
	private String course;
	private double fees;

	public Student(int studentId, String name, int contactNo, String course, double fees) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.contactNo = contactNo;
		this.course = course;
		this.fees = fees;
	}

	public void showDetails() {
		System.out.println("Student Id: " + studentId);
		System.out.println("Student Name: " + name);
		System.out.println("Student Contact Number: " + contactNo);
		System.out.println("Student Course: " + course);
		System.out.println("Fees: " + fees);

	}
	public double getFees() {
		return this.fees;
	}

	public static void findByCourse(Student[] student, String course) {
		boolean flag=true;
	  for(Student s:student) {
		  if(s.course.equals(course)) {
			  s.showDetails();
			  flag=false;
//			  System.out.println("Student Id: " + s.studentId);
//				System.out.println("Student Name: " + s.name);
//				System.out.println("Student Contact Number: " + s.contactNo);
//				System.out.println("Student Course: " + s.course);
//				System.out.println("Fees: " + s.fees);
				System.out.println("------------------------------------------");
		  }
	  }
	  if(flag) {
		  System.out.println("Zero student entrolled this course");
	  }
		
	}

	public static Double findTotalFees(Student[] student) {
		double sum=0.0;
		for(Student s:student) {
			sum+=s.fees;
		}
		return sum;
	}
}
