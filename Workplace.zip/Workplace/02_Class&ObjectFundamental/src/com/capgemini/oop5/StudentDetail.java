package com.capgemini.oop5;

import java.util.Scanner;

public class StudentDetail {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Student[] student = new Student[5];
		System.out.println("Enter the Details of students ");
		for (int i = 0; i < 5; i++) {
			
			int id = scanner.nextInt();
			String name = scanner.next();
			int contactNo = scanner.nextInt();
			String course = scanner.next();
			double fees = scanner.nextDouble();
			student[i] = new Student(id, name, contactNo, course, fees);
			//student[i].showDetails();
		}
		System.out.println("Enter the course to be searched");
		String search = scanner.next();
		Student.findByCourse(student, search);
		System.out.println("Total fees of all Student="+Student.findTotalFees(student));
	}

}
