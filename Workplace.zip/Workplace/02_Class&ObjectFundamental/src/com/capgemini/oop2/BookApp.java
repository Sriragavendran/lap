package com.capgemini.oop2;

public class BookApp {

	public static void main(String[] args) {
		Book book1=new Book();
		book1.setBook("C++",320.00,"Unknown");
		book1.showBook();
		System.out.println("--------");
		Book book2=new Book();
		book2.setBook("Java", 502.0, "Ragavan");
		book2.showBook();

	}

}
