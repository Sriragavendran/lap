package com.capgemini.oop2;

public class Book {
	private String bookName;
	private double bookPrice;
	private String bookAuthor;
	
	public void setBook(String name, double price, String author) {
		bookName=name;
		bookAuthor=author;
		bookPrice=price;
	}

	public void showBook() {
		System.out.println("Book Name: " + bookName);
		System.out.println("Book Author: " + bookAuthor);
		System.out.println("Book Price: " + bookPrice);
	}

	
}
