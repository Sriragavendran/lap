package com.capgemini.oop3;

public class Book {
	private String bookName;
	private double bookPrice;
	private String bookAuthor;
	
	public Book(String name, double price, String author) {
		this.bookName=name;
		this.bookAuthor=author;
		this.bookPrice=price;
	}

	

	public void showBook() {
		System.out.println("Book Name: " + bookName);
		System.out.println("Book Author: " + bookAuthor);
		System.out.println("Book Price: " + bookPrice);
	}

	
}
