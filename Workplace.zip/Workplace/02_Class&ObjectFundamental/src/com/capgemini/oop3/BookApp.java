package com.capgemini.oop3;

public class BookApp {

	public static void main(String[] args) {
		Book book1 = new Book("C++", 320.00, "Unknown");

		book1.showBook();
		System.out.println("--------");
		Book book2 = new Book("Java", 502.0, "Ragavan");

		book2.showBook();

	}

}
