package com.capgemini.oop6;

import java.util.Scanner;

public class VehicleApp {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Vehicle vehicle=new Vehicle("TN21F2233", "UNICORN", 103000.0, 60.5);
		vehicle.getPrice();

	}

}
