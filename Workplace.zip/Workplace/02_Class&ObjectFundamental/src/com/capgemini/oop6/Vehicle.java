package com.capgemini.oop6;

public class Vehicle {
	private String regNo;
	private String brand;
	private double price;
	private double milage;
	public Vehicle(String regNo, String brand, double price, double milage) {
		
		this.regNo = regNo;
		this.brand = brand;
		this.price = price;
		this.milage = milage;
	}
	public void display() {
		System.out.println("RegNo: "+regNo);
		System.out.println("Brand: "+brand);
		System.out.println("Price: "+price);
		System.out.println("Milage: "+milage);
	}
	public void getPrice() {
		System.out.println("Price of Vehicle is "+price);
		
	}
	
}
