
package practiceCoding;

import java.util.Scanner;

public class BackTracking {

	static boolean res[][] = new boolean[4][4];

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int arr[][] = new int[4][4];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				arr[i][j] = scan.nextInt();
			}
		}
		//System.out.println(res[0][0]);
		if (!path(arr, 0, 0, 2, 3)) {
			System.out.println("No way");
		}
	}

	private static boolean path(int[][] arr, int row1, int col1, int row2, int col2) {
		if ((row1 >= 0 && row1 < 4) && (col1 < 4 && col1 >= 0) && arr[row1][col1] == 1&&!res[row1][col1]) {
			   res[row1][col1]=true;
			   if (col1 == col2 && row1 == row2) {
				   System.out.print(row1 + "," + col1+" ->" );
				return true;
			     }

			else if (path(arr, row1 + 1, col1, row2, col2)) {
				System.out.print(row1 + "," + col1 + " ->");
				return true;
			} else if (path(arr, row1, col1 + 1, row2, col2)) {
				System.out.print(row1 + "," + col1 + " ->");
				return true;

			} else if ( path(arr, row1 - 1, col1, row2, col2)) {
				System.out.print(row1 + "," + col1 + " ->");
				return true;
			} else if ( path(arr, row1, col1 - 1, row2, col2)) {
				System.out.print(row1 + "," + col1 + " ->");
				return true;
			}
		}
		return false;
		

	}

}
/*
 * 1 0 0 0 1 1 0 0 1 1 1 1 1 0 0 0
 */