package practiceCoding;

import java.util.Stack;

public class InfixEvaluation {

	public static void main(String[] args) {
		System.out.println(Infixtopostfix("a+(b-c*k)-d"));
		System.out.println(prefixToInfix("+*abc"));
		System.out.println(postfixToprefix("ab*c+"));
		

	}

	private static String postfixToprefix(String string) {
		Stack<String> infixStack=new Stack<>();
		for(int i=0;i<string.length();i++) {
			char c=string.charAt(i);
			if(c=='+'||c=='-'||c=='*'||c=='/') {
				String s1=infixStack.pop();
				String s2=infixStack.pop();
				String tempString=c+s2+s1;
				infixStack.push(tempString);
				System.out.println(infixStack);
			}
			else {
				infixStack.push(c+"");
			}
		}
		///System.out.println(infixStack);
		return infixStack.pop();
	}

	private static String prefixToInfix(String string) {
		Stack<String> infixStack=new Stack<>();
		for(int i=string.length()-1;i>=0;i--) {
			char c=string.charAt(i);
			if(c=='+'||c=='-'||c=='*'||c=='/') {
				//System.out.println(infixStack);
				String tempString=infixStack.pop()+c+infixStack.pop();
				infixStack.push(tempString);
			}
			else {
				infixStack.push(c+"");
			}
		}
		//System.out.println(infixStack);
		return infixStack.pop();
	}

	private static String Infixtopostfix(String infix) {
		Stack<Character> prefix=new Stack<>();
		String str="";
		for(int i=0;i<infix.length();i++) {
		    char c=infix.charAt(i);
		    if(Character.isLetterOrDigit(c)) {
		    	str+=c+"";
		    }
		    else if(c=='(') {
		    	prefix.push(c);
		    }
		    else if(c==')') {
		    	while(!prefix.isEmpty()&&prefix.peek()!='(') {
		    		str+=prefix.pop();
		    	}
		    	prefix.pop();
		    }
		    else {
		    	while(!prefix.isEmpty()&&priority(c)<=priority(prefix.peek())) {
		    		str+=prefix.pop();
		    	}
		    	prefix.push(c);
		    	
		    }
		    
		}
		while(!prefix.isEmpty()) {
			str+=prefix.pop();
		}
		return str;
	}

	private static int priority(char c) {
		if(c=='+'||c=='-') {
			return 1;
		}
		else if(c=='*'||c=='/') {
			return 2;
		}
		else if(c=='^') {
			return 3;
		}
		return -1;
	}

}
