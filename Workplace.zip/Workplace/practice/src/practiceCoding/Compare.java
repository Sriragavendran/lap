package practiceCoding;

import java.util.Comparator;
import java.util.TreeSet;

public class Compare {

	public static void main(String[] args) {
		TreeSet<Integer> set=new TreeSet<>();
        set.add(10);
        set.add(22);
	}

}
class my implements Comparable{

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public boolean equals(Object o) {
		return false;
		
	}
	
}
class MyClass implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
