package com.capgemini.arrays1;

import java.util.Scanner;

public class ArrayDemo3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int ar[]=new int [5];
		System.out.println("Enter the Value");
		for(int i=0;i<ar.length;i++) {
			ar[i]=scanner.nextInt();
		}
		for(int i=0;i<ar.length;i++) {
			
			System.out.println("ar["+i+"]="+ar[i]);
		}
		

	}

}
