package com.capgemini.arrays1;

public class ArrayDemo2 {
	public static void main(String[] args) {
		int arr[] = new int[5];
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 80;
		arr[3] = 30;
		arr[4] = 20;
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		System.out.println(arr[3]);
		System.out.println(arr[4]);

	}
}
