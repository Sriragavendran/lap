package com.capgemini.arrays1;

import java.util.Scanner;

public class ArrayDemo4 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int arr[] = new int[5];
		System.out.println("Enter the value");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println("Enter the value to be searched");
		int search = scanner.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == search) {
				System.out.println(search + " is present in the array at the index of " + (i + 1));
				return;
			}
		}
		System.out.println(search + " is not present in the array");

	}
}
