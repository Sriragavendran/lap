package com.capgemini.arrays1;

public class ArrayDemo1 {
public static void main(String[] args) {
	int size=args.length;
	for(int i=0;i<size;i++) {
		System.out.println(args[i]);
	}
}
}
