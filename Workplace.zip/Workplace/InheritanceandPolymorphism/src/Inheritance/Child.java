package Inheritance;



public class Child extends Parent{
     public Child() {
		System.out.println("Child Class");
	}
	public static void main(String[] args) {
		Child child=new Child();

	}

}
