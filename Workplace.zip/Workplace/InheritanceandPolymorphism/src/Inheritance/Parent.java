package Inheritance;

public class Parent {
  public Parent() {
	System.out.println("Parant Class");
}
}
