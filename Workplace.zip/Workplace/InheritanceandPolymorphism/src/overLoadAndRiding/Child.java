package overLoadAndRiding;

public class Child extends Parent {
	public Child() {
		super(3);

		System.out.println("Child Class");
	}

	public static void main(String[] args) {
		Child child = new Child();
		Parent p = new Parent();

	}

}
