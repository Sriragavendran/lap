package overLoadAndRiding;

public class Parent {
	public Parent() {
	this(4);
		System.out.println("Parent Class");
	}
	public Parent(int i) {
		System.out.println("Parant parameter");
	}
	void m1() {
		System.out.println("Parent M1");
	}
	
}
