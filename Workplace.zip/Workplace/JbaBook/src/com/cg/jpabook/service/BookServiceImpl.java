package com.cg.jpabook.service;

import com.cg.jbabook.dao.BookDao;
import com.cg.jbabook.dao.BookDaoImpl;
import com.cg.jbabook.entities.BookTable;


public class BookServiceImpl implements BookService {

	private BookDao dao;

	public BookServiceImpl() {
		dao = new BookDaoImpl();
	}

	@Override
	public void addBookTable(BookTable book) {
		dao.beginTransaction();
		dao.addBookTable(book);
		dao.commitTransaction();
	}
	
	@Override
	public void updateBookTable(BookTable book) {
		dao.beginTransaction();
		dao.updateBookTable(book);
		dao.commitTransaction();
	}
	
	@Override
	public void removeBookTable(BookTable book) {
		dao.beginTransaction();
		dao.removeBookTable(book);
		dao.commitTransaction();
	}
	
	@Override
	public BookTable findbookById(int id) {
		//no need of transaction, as it's an read operation
		BookTable book  = dao.getBookById(id);
		return book;
	}

	@Override
	public BookTable getBookByPrice(int price) {
		BookTable book  = dao.getBookByPrice(price);
		return book;
	}

	
}
