package com.cg.jpabook.service;

import com.cg.jbabook.entities.BookTable;

public interface BookService {

	public abstract void addBookTable(BookTable book);

	public abstract void updateBookTable(BookTable book);

	public abstract void removeBookTable(BookTable book);

	public abstract BookTable findbookById(int id);
	public abstract BookTable getBookByPrice(int price);

}