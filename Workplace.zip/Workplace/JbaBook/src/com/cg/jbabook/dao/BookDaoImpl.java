package com.cg.jbabook.dao;

import javax.persistence.EntityManager;

import com.cg.jbabook.entities.BookTable;

public class BookDaoImpl implements BookDao {

	private EntityManager entityManager;

	public BookDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public BookTable getBookById(int id) {
		BookTable book = entityManager.find(BookTable.class, id);
		return book;
	}
	@Override
	public BookTable getBookByPrice(int price) {
		BookTable book = entityManager.find(BookTable.class, price);
		return book;
	}

	@Override
	public void addBookTable(BookTable book) {
		entityManager.persist(book);
	}

	@Override
	public void removeBookTable(BookTable book) {
		entityManager.remove(book);
	}

	@Override
	public void updateBookTable(BookTable book) {
		entityManager.merge(book);
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

}
