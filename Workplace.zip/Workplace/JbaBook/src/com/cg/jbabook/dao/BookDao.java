package com.cg.jbabook.dao;

import com.cg.jbabook.entities.BookTable;

public interface BookDao {

	public abstract BookTable getBookById(int id);
	public abstract BookTable getBookByPrice(int price);

	public abstract void addBookTable(BookTable book);

	public abstract void removeBookTable(BookTable book);
	

	public abstract void updateBookTable(BookTable book);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}