package com.cg.jbabook.client;

import java.util.Scanner;

import javax.persistence.TypedQuery;

import com.cg.jbabook.entities.BookTable;
import com.cg.jpabook.service.BookService;
import com.cg.jpabook.service.BookServiceImpl;

public class Client {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		BookService service = new BookServiceImpl();
		while (true) {
			System.out.println("1.Add Book");
			System.out.println("2.Update book");
			System.out.println("3.Find book");
			System.out.println("4.Remove Book");
			System.out.println("Enter the option");
			int option = scanner.nextInt();
			if (option == 1) {
				System.out.println("Enter the id: ");
				int id = scanner.nextInt();
				System.out.println("Enter the autherName");
				String nameString = scanner.next();
				System.out.println("Enter the price:");
				int price = scanner.nextInt();
				BookTable bookTable = new BookTable(id, nameString, price);
				service.addBookTable(bookTable);
			}
			else if (option == 2) {
				System.out.println("Enter the id to uptade the book");
				int id = scanner.nextInt();
				BookTable bookTable = service.findbookById(id);
				System.out.println("Enter author Name");
				String nameString = scanner.next();
				bookTable.setAuthorName(nameString);
				System.out.println("Enter the price");
				int price = scanner.nextInt();
				bookTable.setPrice(price);
			}
			else if(option==3) {
				System.out.println("Enter the id to be searched");
				int id=scanner.nextInt();
				BookTable bookTable=service.findbookById(id);
				bookTable.print();
				//TypedQuery<BookTable> bQuery=service.createQuery("SELECT c FROM Country c", BookTable.class);
				System.out.println("Enter price to be search");
				int price =scanner.nextInt();
				BookTable bookTable2=service.getBookByPrice(price);
				bookTable.print();
			}
			else {
				break;
			}
		}

	}
}
