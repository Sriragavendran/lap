package com.cg.jbabook.entities;



import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book")
public class BookTable implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	private int bookId;
	private String authorName;
	private int price;
	public int getBookId() {
		return bookId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public int getPrice() {
		return price;
	}
	public BookTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookTable(int id, String nameString, int price2) {
		this.bookId=id;
		this.authorName=nameString;
		this.price=price2;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void print() {
		System.out.println("Book id:"+this.bookId);
		System.out.println("Book authorName:"+this.authorName);
		System.out.println("Book price:"+this.price);
		
		
	}
}
