package intermediateOperation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApiAll {

	public static void main(String[] args) {

		ArrayList<Integer> arr = new ArrayList<Integer>(Arrays.asList(2, 5, 7, 9, 12, 56));

		System.out.println(arr);

		List<Integer> l = arr.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());

		System.out.println(l);

		List<Integer> l1 = arr.stream().map(i -> i * i).collect(Collectors.toList());

		System.out.println(l1);

		long cn = arr.stream().count();

		System.out.println("count " + cn);
		Integer minVal = arr.stream().min((i1, i2) -> i1.compareTo(i2)).get();

		System.out.println("minimum= " + minVal);

		Integer maxVal = arr.stream().max((i1, i2) -> i1.compareTo(i2)).get();

		System.out.println("Maximun= " + maxVal);

		List<Integer> l2 = arr.stream().sorted((a, b) -> (a < b) ? 1 : (a > b) ? -1 : 0).collect(Collectors.toList());

		System.out.println("sort " + l2);

		arr.stream().forEach(i -> {

			System.out.println("the elements are " + i);
		});

	}

}