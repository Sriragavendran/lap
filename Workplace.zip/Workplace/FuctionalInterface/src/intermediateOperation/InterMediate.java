package intermediateOperation;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class InterMediate {

	public static void main(String[] args) {

		List<Integer> number = Arrays.asList(2, 5, 7, 9, 5, 4, 2);

		List<Integer> resultIntegers = number.stream().map(x -> (x * 2)).collect(Collectors.toList());

		List result1 = resultIntegers.stream().sorted().collect(Collectors.toList());

		System.out.println(resultIntegers + " \n Sorted order--" + result1);

		Set set = resultIntegers.stream().sorted().collect(Collectors.toSet());

		result1.stream().forEach(i -> System.out.println(i));

		Integer num = (Integer) result1.stream().min((i1, i2) -> ((Integer) i1).compareTo((Integer) i2)).get();
		System.out.println(num);

		System.out.println(set);
	}
}
