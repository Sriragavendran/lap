package lap04.exercise01;

import java.util.Random;

class Account {
	private long accNum;
	private double balance;
	private Person accHolder;

	public Account(long accNum, double balance, Person accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	void deposit(double amount) {
		balance += amount;

	}
	void withdraw(double amount) {
		
		balance-=amount;
	}
	double getBalance() {
		return balance;
	}

}
public class SavingsAccount extends Account{
	public static final double minimumBalance=500;
	public SavingsAccount(long accNum, double balance, Person accHolder) {
		super(accNum, balance, accHolder);
		
	}
	@Override
	void withdraw(double amount) {
	   if(super.getBalance()+minimumBalance<amount) {
		super.withdraw(amount);
	   }
	   else {
		   System.out.println("Your balance is less than minimum balance ... so you can't withdraw");
	   }
	}

	public static void main(String[] args) {
		
		Random random=new Random();
		SavingsAccount smithAccount=new SavingsAccount(random.nextLong(), 2000.0, new Person("smith",30));
		SavingsAccount kathyAccount=new SavingsAccount(random.nextLong(), 3000.0, new Person("Kathy",28));
		smithAccount.deposit(2000);
		kathyAccount.withdraw(2000);
		System.out.println("Account Balance\n1.Smith Account = "+smithAccount.getBalance()+"\n2.kathy Account = "+kathyAccount.getBalance());
	}

}
