package lap04.exercise01;

public class Person {
	private String name;
	private float age;

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public float getAge() {
		return age;
	}

}
