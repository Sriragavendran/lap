package lap01.exercise08;

import java.util.Scanner;



public class PowerNumber {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number");
		int number=scanner.nextInt();
		if(checkNumber(number)) {
			System.out.println(number+" is power of 2");
		}
		else {
			System.out.println(number+" is not power of 2");
		}

	}

	private static boolean checkNumber(int number) {
		int sum=1;
		for(int i=1;sum<number;i++) {
			sum*=2;
		}
		if(sum==number) return true;
		else return false;
	}

}
