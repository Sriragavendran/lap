package lap01.exercise03;

import java.util.Scanner;

public class FibanocciSeries {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int number = scan.nextInt();
		System.out.println("Nth Fibanocci Number = "+fib(number));

	}

	private static int fib(int number) {
		 int a = 0, b = 1, c; 
	        if (number == 0) 
	            return a; 
	        for (int i = 2; i <= number; i++) { 
	            c = a + b; 
	            a = b; 
	            b = c; 
	        } 
	        return b;

	}

}
