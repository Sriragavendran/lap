package lap01.exercise03;

import java.util.Scanner;

public class FibanocciSeriesRecursion {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number");
		int number = scan.nextInt();
		System.out.println("Nth Fibanocci Number = "+fib(number));

	}

	public static int fib(int number) {
		
		
		    { 
		        if (number <= 1) 
		            return number; 
		        return fib(number - 1) + fib(number - 2); 
		    } 
	}
}
