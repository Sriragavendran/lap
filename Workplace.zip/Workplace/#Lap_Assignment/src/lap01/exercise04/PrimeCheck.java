package lap01.exercise04;

import java.util.Scanner;

public class PrimeCheck {
	
	    public static void prime(int number) {
	    	for(int i=2;i<=Math.sqrt(number);i++) {
				if(number%i==0) {
					//System.out.println(number+" is not a Prime Number");
					return;
				}
			}
			System.out.print(number+" ");
	    }
		public static void main(String[] args) {
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter the number");
			int number=scan.nextInt();
			for(int i=1;i<number;i++) {
				prime(i);
			}

		}

}
