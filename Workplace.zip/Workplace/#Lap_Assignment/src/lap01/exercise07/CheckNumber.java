package lap01.exercise07;

import java.util.Scanner;

public class CheckNumber {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number");
		int number=scanner.nextInt();
		if(checkNumber(number))
		System.out.println(number+" is Increasing number");
		else
			System.out.println(number+" is not Increasing number");

	}

	private static boolean checkNumber(int number) {
		int a=number%10;
		number/=10;
		while(number-->0) {
			int n=number%10;
			if(n>a) {
				return false;
			}
			a=n;
			number/=10;
		}
		return true;
	}

}
