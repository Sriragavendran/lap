package lap01.exercise01;

import java.util.Scanner;

public class SolutionExercise01 {
	public static int sumofcubes(int number) {
		int sum=0;
		while(number>0) {
			int lastdigit=number%10;
			sum+=lastdigit*lastdigit*lastdigit;
			number/=10;
		}
		return sum;
	}

	public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the number");
        int number=scan.nextInt();
        System.out.println("Result="+sumofcubes(number));
	}

}
