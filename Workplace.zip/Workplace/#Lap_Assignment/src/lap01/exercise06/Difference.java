package lap01.exercise06;

import java.util.Scanner;

public class Difference {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the number");
		int number=scanner.nextInt();
		System.out.println("Difference between the sum of the squares and the square of the sum = "+calculateDifference(number));

	}

	private static int calculateDifference(int number) {
		int sum1=0,sum2=0;
		for(int i=1;i<=number;i++) {
			sum1+=(i*i);
			sum2+=i;
		}
		System.out.println(sum1+" "+sum2);
		return (sum1-(sum2*sum2));
	}

}
