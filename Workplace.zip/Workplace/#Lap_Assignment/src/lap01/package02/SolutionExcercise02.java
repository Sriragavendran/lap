package lap01.package02;
import java.util.*;
public class SolutionExcercise02 {

	public static void main(String[] args) {
		Scanner scan=new Scanner (System.in);
		System.out.println("Enter the Button");
		String s=scan.nextLine();
		if(s.equals("red")) {
			System.out.println("Stop");
		}
		else if(s.equals("yellow")) {
			System.out.println("Ready");
		}
		else {
			System.out.println("Go");
		}
		

	}

}
