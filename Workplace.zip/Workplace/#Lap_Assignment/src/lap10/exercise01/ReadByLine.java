package lap10.exercise01;

import java.io.*;

class ReadByLine {
	public static void main(String args[]) throws IOException {
		try {
			File file=new File("G:\\New folder\\capgemini material\\documents\\input.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
			int count=1;
			while (line != null) {
				System.out.println(count+"."+line);
				line = br.readLine();
				count++;
			}
			br.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("File Not Found");
		}
	}

}
