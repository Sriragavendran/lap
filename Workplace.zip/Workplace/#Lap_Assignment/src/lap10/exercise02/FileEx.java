package lap10.exercise02;

import java.io.*;

class FileEx {
	public static void main(String[] args) throws IOException {
		File f = new File("G:\\New folder\\capgemini material\\documents\\input.txt");
		System.out.println("File exist or not "+f.exists());
		System.out.println("Can we read? "+f.canRead());
		System.out.println("Can we Write? "+f.canWrite());
		System.out.println("File Size " +(byte)f.length());
		System.out.println("File type " +f.getName());
		

	}
}
