package lap9.exercise03;

public class UsernameAndPassword {

	public static void main(String[] args) {
		String s=null;
		get(s);
		System.out.println(s);

	}

	private static void get(String s) {
		s="sfffd";
		
	}

}
