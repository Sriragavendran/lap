package lap9.exercise01;

import java.util.Scanner;
import java.util.function.BiFunction;

public class LamdaExpression {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = scanner.nextInt();
		int y = scanner.nextInt();
		BiFunction<Integer, Integer, Double> func2 = (x1, x2) -> Math.pow(x1, x2);
		System.out.println(func2.apply(x, y));

	}

}
