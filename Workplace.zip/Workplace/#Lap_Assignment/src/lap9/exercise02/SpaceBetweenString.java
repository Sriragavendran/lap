package lap9.exercise02;

import java.util.Scanner;
import java.util.function.Function;


public class SpaceBetweenString {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String string=scanner.next();
		//char c[]=scanner.next().toCharArray();
		 Function<String, String> function=s->{
			 String s1="";
			 for (Character c : s.toCharArray()) {
				 s1+=c+" ";
			}
			return s1;
		 };
		 System.out.println(function.apply(string));
		
	}

}
