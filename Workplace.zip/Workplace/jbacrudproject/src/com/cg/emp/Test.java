package com.cg.emp;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("jpacurd");
		EntityManager entitymanager = emfactory.createEntityManager();
		
		Employee emp = new Employee(123, "ragav", "chennai", 2000);
	
		entitymanager.getTransaction().begin();
		entitymanager.persist(emp); // save
		entitymanager.getTransaction().commit();
	}

}
