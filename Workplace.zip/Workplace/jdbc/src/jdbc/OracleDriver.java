package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OracleDriver {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		 //load the driver class ojdbc.jar
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 // create the connection 
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "capgemini", "capgemini1999"); 
		// create the statement
		Statement statement =connection.createStatement();
		// execute query 3 methods execute(),executeUpdate(),executeQuery() ->ddl -->dml // -->drl
		ResultSet result = statement.executeQuery("select * from employee");
		while(result.next()) { System.out.println(result.getString("NAME")+" "+result.getString(2));
		// close the connection
		}
		connection.close();
		}

	}


