package loginDetail;

import java.util.Scanner;

public class LoginSolution {

	public static void main(String[] args) {
		String userName = "capgemini";
		String password = "Abc@123";
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the UserName");
		String name = scanner.next();
		System.out.println("Enter the Password");
		String passString = scanner.next();
		if (userName.equalsIgnoreCase(name) && password.equals(passString)) {
			System.out.println("Welcome to Capgemini");
		} else {
			System.out.println("Enter valid credentials");
		}
	
	}

}
