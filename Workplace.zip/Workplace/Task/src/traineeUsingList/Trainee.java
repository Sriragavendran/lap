package traineeUsingList;

import java.time.LocalDate;
import java.util.ArrayList;

public class Trainee {

	private long traineeid;
	private String traineeName;
	private Double salary;
	private LocalDate dateOfJoiningDate;
	private String emailString;
	private String phone;

	public Trainee(long traineeid, String traineeName, Double d, LocalDate i, String emailString, String phone) {
		super();
		this.traineeid = traineeid;
		this.traineeName = traineeName;
		this.salary = d;
		this.dateOfJoiningDate = i;
		this.emailString = emailString;
		this.phone = phone;
	}

	public Trainee() {

	}

	public long getTraineeid() {
		return traineeid;
	}

	public void setTraineeid(long traineeid) {
		this.traineeid = traineeid;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public void setDateOfJoiningDate(LocalDate dateOfJoiningDate) {
		this.dateOfJoiningDate = dateOfJoiningDate;
	}

	public void setEmailString(String emailString) {
		this.emailString = emailString;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public Double getSalary() {
		return salary;
	}

	public LocalDate getDateOfJoiningDate() {
		return dateOfJoiningDate;
	}

	public String getEmailString() {
		return emailString;
	}

	public String getPhone() {
		return phone;
	}

	public void display() {
		System.out.println("Trainee Id : " + this.traineeid);
		System.out.println("Trainee Name : " + this.traineeName);
		System.out.println("Trainee Salary : " + this.salary);
		System.out.println("Trainee Joining Date : " + this.dateOfJoiningDate);
		System.out.println("Trainee EmailId : " + this.emailString);
		System.out.println("Trainee phone : " + this.phone);

	}

	public void updateDetails(long updateId, ArrayList<Trainee> list) {
		for (Trainee t : list) {
			if (t.getTraineeid() == updateId) {
				t.setSalary(30000.0);
				t.setPhone("97851378952");
			}
		}

	}

	public void searchTraineeId(long id, ArrayList<Trainee> list) {
		boolean f = true;
		for (Trainee t : list) {
			if (t.getTraineeid() == id) {
				System.out.println("Yes");
				t.display();
				f = false;
				break;
			}
		}
		if (f) {

			System.out.println("Id Not Found");

		}

	}

	public void removeById(long removeId, ArrayList<Trainee> list) {
		for (Trainee t : list) {
			if (t.getTraineeid() == removeId) {

			list.remove(removeId);
				this.display();

			}
		}
	}

}
