package fileTask;

import java.io.Serializable;

public class Trainee implements Serializable {

	private long traineeId;
	private String traineeName;
	private String emailString;
	private String phone;

	public Trainee(Long id, String traineeName, String emailString, String phone) {
		super();
		this.traineeId=id;
		this.traineeName = traineeName;
		this.emailString = emailString;
		this.phone = phone;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public String getEmailString() {
		return emailString;
	}

	public String getPhone() {
		return phone;
	}

	public void display() {
		System.out.println("Trainee id : "+this.traineeId);
		System.out.println("Trainee Name : " + this.traineeName);
		System.out.println("Trainee EmailId : " + this.emailString);
		System.out.println("Trainee phone : " + this.phone);

	}

}
