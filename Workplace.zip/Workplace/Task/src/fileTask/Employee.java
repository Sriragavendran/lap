package fileTask;

import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class Employee {

	public static void main(String[] args) throws Exception{
		Scanner scanner = new Scanner(System.in);
		File file = new File("G:\\capgemini material\\test question\\Employee\\task1.txt");
		file.createNewFile();
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);
		System.out.println("Enter the Id");
		long id = scanner.nextLong();
		System.out.println("Enter the Name");
		String name = scanner.next();
		System.out.println("Enter the Email id");
		String email = scanner.next();
		System.out.println("Enter the Phone Number");
		String phone = scanner.next();
		Trainee trainee2 = new Trainee(id,name, email, phone);
		outputStream.writeObject(trainee2);
		
		
		FileInputStream fileInputStream=new FileInputStream(file);
		ObjectInputStream objectInputStream=new ObjectInputStream(fileInputStream);
		Trainee readTrainee=(Trainee)objectInputStream.readObject();
	    readTrainee.display();
	}

}
