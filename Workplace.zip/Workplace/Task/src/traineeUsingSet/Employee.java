package traineeUsingSet;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
public class Employee {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Trainee trainee=new Trainee();
		Set<Trainee> set = new TreeSet<>();
		while (true) {
			System.out.println("------------Trainee Management-------------");
			System.out.println("1.Add Data");
			System.out.println("2.Update data");
			System.out.println("3.Search data");
			System.out.println("4.Remove data");
			System.out.println("5.Exit");
			int val = scanner.nextInt();
			if (val == 1) {
               System.out.println("Enter the Id");
               long id=scanner.nextLong();
               System.out.println("Enter the Name");
               String name=scanner.next();
               System.out.println("Enter the salary");
               double salary=scanner.nextDouble();
               System.out.println("Enter the data of Joining");
               LocalDate localDate=LocalDate.of(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
               System.out.println("Enter the Email id");
               String email=scanner.next();
               System.out.println("Enter the Phone Number");
               String phone=scanner.next();
               Trainee trainee2=new Trainee(id,name, salary, localDate, email, phone);
				set.add(trainee2);
               }
			else if(val==2) {
				System.out.println("Enter the id to be changed");
				long id=scanner.nextLong();
				for (Trainee t : set) {
					if (t.getTraineeid() == id) {
						set.remove(id);
						 System.out.println("Enter the Id");
			               long Id=scanner.nextLong();
			               System.out.println("Enter the Name");
			               String name=scanner.next();
			               System.out.println("Enter the salary");
			               double salary=scanner.nextDouble();
			               System.out.println("Enter the data of Joining");
			               LocalDate localDate=LocalDate.of(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());
			               System.out.println("Enter the Email id");
			               String email=scanner.next();
			               System.out.println("Enter the Phone Number");
			               String phone=scanner.next();
			               Trainee trainee2=new Trainee(Id,name, salary, localDate, email, phone);
			              set.add(trainee2);
						
					}
				}
			
			}
			else if(val==3) {
				System.out.println("Enter the id to be searched");
				long id=scanner.nextLong();
				boolean f = true;
				for (Trainee t : set) {
					if (t.getTraineeid() == id) {
						System.out.println("Yes");
						t.display();
						f = false;
						break;
					}
				}
				if (f) {

					System.out.println("Id Not Found");

				}

				
			}
			else if(val==4) {
				System.out.println("Enter the id to be removed");
				long removeId=scanner.nextLong();
				for (Trainee t : set) {
					if (t.getTraineeid() == removeId) {

						set.remove(t);
						System.out.println("Details Removed Successfully");
					}

					}
			}
			else {
				
				break;
			}
		}
	}

}
