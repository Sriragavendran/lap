package traineeManagement;

import java.time.LocalDate;

public class Trainee {

	private long traineeid;
	private String traineeName;
	private Double salary;
	private LocalDate dateOfJoiningDate;
	private String emailString;
	private String phone;
	public Trainee(long traineeid, String traineeName, Double d, LocalDate i, String emailString,
			String phone) {
		super();
		this.traineeid = traineeid;
		this.traineeName = traineeName;
		this.salary = d;
		this.dateOfJoiningDate = i;
		this.emailString = emailString;
		this.phone = phone;
	}
	public long getTraineeid() {
		return traineeid;
	}
	public void setTraineeid(long traineeid) {
		this.traineeid = traineeid;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public void setDateOfJoiningDate(LocalDate dateOfJoiningDate) {
		this.dateOfJoiningDate = dateOfJoiningDate;
	}
	public void setEmailString(String emailString) {
		this.emailString = emailString;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public Double getSalary() {
		return salary;
	}
	public LocalDate getDateOfJoiningDate() {
		return dateOfJoiningDate;
	}
	public String getEmailString() {
		return emailString;
	}
	public String getPhone() {
		return phone;
	}
	

	public void display() {
		System.out.println("Trainee Id : "+this.traineeid);
		System.out.println("Trainee Name : "+this.traineeName);
		System.out.println("Trainee Salary : "+this.salary);
		System.out.println("Trainee Joining Date : "+this.dateOfJoiningDate);
		System.out.println("Trainee EmailId : "+this.emailString);
		System.out.println("Trainee phone : "+this.phone);
		
	}
	


	

}
