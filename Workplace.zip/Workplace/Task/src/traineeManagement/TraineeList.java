package traineeManagement;

import java.time.LocalDate;
import java.util.ArrayList;



public class TraineeList {

	public void searchTraineeId(long id, ArrayList<Trainee> list) {
		boolean f = true;
		for (Trainee t : list) {
			if (t.getTraineeid() == id) {
				System.out.println("Yes");
				t.display();
				f = false;
				break;
			}
		}
		if (f) {

			System.out.println("Id Not Found");

		}

	}

	public void updateTrainee(long updateId, ArrayList<Trainee> list) {
		for (Trainee t : list) {
			if (t.getTraineeid() == updateId) {
				t.setSalary(30000.0);
				t.setPhone("97851378952");
			}
		}

	}

	public void addTrainee(ArrayList<Trainee> list) {

		Trainee trainee = new Trainee(46044548, "Tom", 22500.0, LocalDate.of(2020, 10, 13), "Tom@Capgemini.com",
				"98745852442");
		list.add(trainee);

	}

	public void removeById(long removeId, ArrayList<Trainee> list) {
		for (Trainee t : list) {
			if (t.getTraineeid() == removeId) {
				int index=list.indexOf(t.getTraineeid());
				
			}
		}

	}

}
