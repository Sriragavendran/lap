package traineeManagement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class EmployeeDetail {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Trainee trainee1 = new Trainee(46044545, "James", 22500.0, LocalDate.of(2020, 10, 13), "james@Capgemini.com",
				"9786543221");
		Trainee trainee2 = new Trainee(46044748, "Bond", 22500.0, LocalDate.of(2020, 10, 13), "Bond@Capgemini.com",
				"9788585452");
		ArrayList<Trainee> list = new ArrayList<>();
		list.add(trainee1);
		list.add(trainee2);

		TraineeList traineeList = new TraineeList();
		System.out.println("Enter the details of Trainee to add");
		traineeList.addTrainee(list);
		System.out.println("Enter the Trainee Id to be Searched");
		long traineeId = scanner.nextLong();
		traineeList.searchTraineeId(traineeId, list);
		System.out.println("Enter the Trainee id To Update");
		long UpdateId = scanner.nextLong();
		traineeList.updateTrainee(UpdateId, list);
		System.out.println("Enter the Trainee Id to be Removed");
		long removeId = scanner.nextLong();
		traineeList.removeById(removeId, list);

	}

}
