package com.capgemini.Interface;

interface Parent {
	void m1();

	void m2();
}

public class Interface01 implements Parent {

	public static void main(String[] args) {
      Interface01 interface01=new Interface01();
      interface01.m1();
      interface01.m2();
      Parent parent=new Interface01();
	}

	@Override
	public void m1() {
		System.out.println("Parent m1");

	}

	@Override
	public void m2() {
		System.out.println("Parent m2");

	}

}
