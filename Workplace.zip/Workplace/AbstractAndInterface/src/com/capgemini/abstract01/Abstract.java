package com.capgemini.abstract01;
abstract class Parent{
	abstract void m1();
}
public class Abstract extends Parent{

	public static void main(String[] args) {
	 Abstract abstract1=new Abstract();
	 abstract1.m1();

	}

	@Override
	void m1() {
		System.out.println("Abstract Class");
		
	}

}
